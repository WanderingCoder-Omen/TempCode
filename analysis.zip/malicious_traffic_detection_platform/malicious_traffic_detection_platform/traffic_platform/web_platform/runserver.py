from traffic_platform.web_platform import app

if __name__=="__main__":
    app.run(debug=True,port=7000)
