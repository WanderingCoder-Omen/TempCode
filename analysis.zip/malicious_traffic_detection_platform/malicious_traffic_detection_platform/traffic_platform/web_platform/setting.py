
DEBUG = True

SQLALCHEMY_TRACK_MODIFICATIONS = False

SECRET_KEY='random string'

SQLALCHEMY_DATABASE_URI = 'sqlite:///students.sqlite3'

UPLOAD_FOLDER ='traffic_platform/web_platform/upload/'        
#MAX_CONTENT_LENGTH = 20000000     
