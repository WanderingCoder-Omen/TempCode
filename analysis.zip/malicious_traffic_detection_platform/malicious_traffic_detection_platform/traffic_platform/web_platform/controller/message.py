import os
# from web_platform import db
from flask import request,render_template,flash,abort,url_for,redirect,session,Flask
from werkzeug.utils import secure_filename
from flask import jsonify
# import sys
# sys.path.append('...')
from ...train_test.main import analysis
from ...web_platform import app


ALLOWED_EXTENSIONS = {'csv', 'pcap'}
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def upload():
    return render_template('upload.html')

@app.route('/error',methods=['POST','GET'])
def show_error():
    if request.method == 'POST':
        return redirect(url_for("upload"))
    else:
        return render_template('show_error.html')

@app.route('/detection',methods = ['POST','GET'])
def detection():
    print("In Detection")
    error=None
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(url_for('show_error'))
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            flash('No selected file')
            return redirect(url_for('show_error'))
        if file and allowed_file(file.filename):
            print("Started Processing")
            filename = secure_filename(file.filename)
            pcap_save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            csv_sava_path=os.path.join(app.config['UPLOAD_FOLDER'],'result.csv')
            file.save(pcap_save_path)
            print("upload file is successfully saved !")
            # return "upload file is successful!"
            x = analysis(pcap_save_path,csv_sava_path,num_epoch=10,num_ev=30)
            print(x.tolist().count(1))
            score = x.tolist().count(1)/0.6
            print("Score= %f",score)
            if score > 21:
                verdict = "Unwanted/Malicious Apps have been installed"
            if score < 15:
                verdict = "Benign"
            if score >= 15 and score <=21:
                verdict = "Unsure. Please check your phone for any unusual apps installed recently"
            data = {'AI Score': score,'Verdict': verdict}
            os.remove(pcap_save_path)
            os.remove(csv_sava_path)
            return jsonify(data)


@app.route('/result',methods=['POST','GET'])
def result():
    if request.method == 'POST':
        return redirect(url_for("upload"))
    else:
        return render_template('show_error.html')    
