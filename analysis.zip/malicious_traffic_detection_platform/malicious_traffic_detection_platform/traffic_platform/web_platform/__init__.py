# -*- coding: utf-8 -*-
from flask import Flask
from flask_sqlalchemy import SQLAlchemy


app=Flask(__name__)

# import sys
# sys.path.append('..')
from .controller import message





app.config.from_object('traffic_platform.web_platform.setting')  
app.config.from_envvar('FLASKR_SETTINGS')  


