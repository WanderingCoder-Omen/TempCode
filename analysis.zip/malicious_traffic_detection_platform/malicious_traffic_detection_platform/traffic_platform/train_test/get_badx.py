#!/usr/bin/env python
# -*- coding:utf-8 -*-

import scapy.all as scapy

from .get_goodx import PcapDecode

NUM_BAD=1000000 


class GetBadx():
    def __init__(self,bad_filename,bad_pcap_filename,num):
        self.bad_filename=bad_filename
        self.bad_pcap_filename=bad_pcap_filename
        self.num=num
    def get(self):
        """
        
        """
        PD = PcapDecode()
        scapy.load_layer('tls')
        with open(self.bad_filename, 'a') as f:
            with scapy.PcapReader(self.bad_pcap_filename) as packets:
                for i, pkt in enumerate(packets):
                    data = PD.ether_decode(pkt)
                    [f.write("{},".format(value)) for key,value in data.items()]
                    # [f.write("{}:{}, ".format(key, value)) for key, value in data.items()]
                    f.write("bad\n")
                    if i==self.num:
                        print("Malicious Packets Processed {}".format(i))
                        return True



if __name__=="__main__":
    bad_filename='./badx.csv'
    bad_pcap_filename="traffic_platform/train_test/danger_pcap/RAT07_AhMyth.pcap"
    get_badx=GetBadx(bad_filename,bad_pcap_filename,100).get()


